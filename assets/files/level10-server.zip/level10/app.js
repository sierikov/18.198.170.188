const express = require("express");

const app = express();
const port = process.env.PORT || 443;

app.get("/add", function (req, res) {
  let a = BigInt(req.query?.a);
  let b = BigInt(req.query?.b);
  res.send(`${a + b}`);
  console.log(`Got a: ${a}, b: ${b}`);
});

app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});
